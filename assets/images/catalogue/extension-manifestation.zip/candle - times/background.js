const API_KEY = 'YOUR_API_NINJAS_API_KEY'; // Replace with your actual API key

function getSynonyms(word) {
  return fetch(`https://api.api-ninjas.com/v1/thesaurus?word=${encodeURIComponent(word)}`, {
    headers: { 'X-Api-Key': API_KEY }
  })
    .then(response => response.json())
    .then(data => data.synonyms || [])
    .catch(error => {
      console.error('Error fetching synonyms:', error);
      return [];
    });
}

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.url.includes('google.com/search')) {
    const searchParams = new URL(details.url).searchParams;
    const query = searchParams.get('q');
    if (query) {
      chrome.storage.sync.get(['manifestations'], async (result) => {
        let manifestations = result.manifestations || [];
        let updated = false;
        for (let item of manifestations) {
          const wishWords = item.wish.toLowerCase().split(' ');
          const queryWords = query.toLowerCase().split(' ');
          
          let isManifested = true;
          for (let wishWord of wishWords) {
            const synonyms = await getSynonyms(wishWord);
            const matchFound = queryWords.some(queryWord => 
              queryWord === wishWord || synonyms.includes(queryWord)
            );
            if (!matchFound) {
              isManifested = false;
              break;
            }
          }

          if (isManifested) {
            item.count++;
            updated = true;
            chrome.notifications.create({
              type: 'basic',
              iconUrl: 'assets/candle.gif',
              title: 'Manifestation Update',
              message: `You have just manifested "${item.wish}" once again!`
            });
          }
        }
        if (updated) {
          chrome.storage.sync.set({ manifestations });
        }
      });
    }
  }
});