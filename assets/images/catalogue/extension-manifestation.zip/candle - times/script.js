document.addEventListener('DOMContentLoaded', () => {
    const wishInput = document.getElementById('wishInput');
    const manifestBtn = document.getElementById('manifestBtn');
    const manifestationsGrid = document.getElementById('manifestations');

    // Load existing manifestations
    loadManifestations();

    manifestBtn.addEventListener('click', () => {
        const wish = wishInput.value.trim();
        if (wish) {
            addManifestation(wish);
            wishInput.value = '';
        }
    });

    function loadManifestations() {
        chrome.storage.sync.get(['manifestations'], (result) => {
            const manifestations = result.manifestations || [];
            manifestationsGrid.innerHTML = ''; // Clear the grid
            manifestations.forEach(item => addManifestationToGrid(item));
        });
    }

    function addManifestation(wish) {
        chrome.storage.sync.get(['manifestations'], (result) => {
            const manifestations = result.manifestations || [];
            manifestations.push({ wish, count: 0 });
            chrome.storage.sync.set({ manifestations }, () => {
                addManifestationToGrid({ wish, count: 0 });
            });
        });
    }

    function addManifestationToGrid(item) {
        const itemElement = document.createElement('div');
        itemElement.className = 'manifestation-item';
        itemElement.innerHTML = `
            <button class="delete-btn">×</button>
            <img src="assets/candle.gif" alt="Candle">
            <h2>${item.wish}</h2>
            <p class="counter">Times Manifested: ${item.count}</p>
        `;
        
        // Add event listener for delete button
        const deleteBtn = itemElement.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', () => deleteManifestation(item.wish));
        
        manifestationsGrid.appendChild(itemElement);
    }

    function deleteManifestation(wish) {
        chrome.storage.sync.get(['manifestations'], (result) => {
            let manifestations = result.manifestations || [];
            manifestations = manifestations.filter(item => item.wish !== wish);
            chrome.storage.sync.set({ manifestations }, () => {
                loadManifestations(); // Reload the grid after deletion
            });
        });
    }

    // Listen for storage changes
    chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === 'sync' && changes.manifestations) {
            loadManifestations();
        }
    });

    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'assets/candle.gif',
        title: 'Manifestation Update',
        message: `You have just manifested "${item.wish}" once again!`,
        priority: 2,
        requireInteraction: true
      });
});